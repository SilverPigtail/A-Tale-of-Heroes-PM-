package com.alejandro.ataleofheroes.constants;

public class Constants {
    public final static double gameVersion = 0.05f;
}
