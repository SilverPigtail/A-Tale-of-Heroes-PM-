package gameobjects;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Vector3;

import java.util.Vector;

/***
 * Unused class, this class will be deleted.
 */
public class character {

    private Sprite cSprite;
    private Vector3 pTiles;
    private OrthographicCamera cCamera;
    private Batch sBatch;
    private TiledMap cMap;

    public character(OrthographicCamera cCamera, TiledMap cMap) {
        
    }
}
