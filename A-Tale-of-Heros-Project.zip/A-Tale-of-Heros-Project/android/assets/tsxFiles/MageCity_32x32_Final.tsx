<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="MageCity_32x32_Final" tilewidth="32" tileheight="32" tilecount="360" columns="8">
 <image source="../atlasPNG/magecity.png" width="256" height="1450"/>
</tileset>
