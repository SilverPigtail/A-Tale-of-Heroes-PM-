<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="MageCity16x16" tilewidth="16" tileheight="16" tilecount="1440" columns="16">
 <image source="../atlasPNG/magecity.png" width="256" height="1450"/>
</tileset>
