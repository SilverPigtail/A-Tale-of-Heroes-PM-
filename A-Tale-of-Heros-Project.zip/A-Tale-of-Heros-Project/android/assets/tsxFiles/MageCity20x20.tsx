<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="MageCity20x20" tilewidth="20" tileheight="20" tilecount="864" columns="12">
 <image source="../atlasPNG/magecity.png" width="256" height="1450"/>
</tileset>
